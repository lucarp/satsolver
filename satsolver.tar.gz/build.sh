g++ solver.cc -o sat_solver.exec
echo "Le fichier executable a ete cree et appele sat_solver.exec"
chmod -u=x sat_solver.exec
echo "Le fichier est executable."
echo "USAGE: ./sat_solver.exec <<chemin_du_fichier_Dimacs>>"

